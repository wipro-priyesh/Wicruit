package com.wipro.wicruit;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;

public class StudentRegistration extends AppCompatActivity {

    DatabaseClass myDB1;
    Spinner typeOf;
    Spinner passW;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_registration);

        myDB1 = new DatabaseClass(this);

        Button Submit = (Button) this.findViewById(R.id.submitBtn);

        Submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText etFirstName = (EditText) findViewById(R.id.firstNameET);
                String FirstName = etFirstName.getText().toString();

                EditText etSurname = (EditText) findViewById(R.id.SurnameET);
                String Surname = etSurname.getText().toString();

                EditText etEmail = (EditText) findViewById(R.id.EmaileET);
                String Email = etEmail.getText().toString();

                Spinner spTypeOfDeg = (Spinner) findViewById(R.id.spinnerToD);
                String TypeOfDegree = spTypeOfDeg.getSelectedItem().toString();

                EditText etCourseTitle = (EditText) findViewById(R.id.CourseTitleET);
                String CourseTitle = etCourseTitle.getText().toString();

                EditText etYearOfGrad = (EditText) findViewById(R.id.YearOfGradeET);
                String YearOfGrad = etYearOfGrad.getText().toString();

                Spinner spPassType = (Spinner) findViewById(R.id.spinnerPass);
                String PassType = spPassType.getSelectedItem().toString();

                myDB1.insertStudentData(FirstName,Surname,Email,TypeOfDegree,CourseTitle,YearOfGrad,PassType);

                Toast.makeText(StudentRegistration.this, FirstName + " " + TypeOfDegree + " " + CourseTitle + " " + PassType, Toast.LENGTH_LONG).show();
                Intent intent = new Intent(StudentRegistration.this, StudentRegisterScreen.class);
                startActivity(intent);
            }
        });

        typeOf = (Spinner) findViewById(R.id.spinnerToD);
        passW = (Spinner) findViewById(R.id.spinnerPass);

        ArrayList<String> typeOfDegree = new ArrayList<String>();
        typeOfDegree.add("Type of Degree");
        typeOfDegree.add("BSc");
        typeOfDegree.add("BA");
        typeOfDegree.add("BEng");
        typeOfDegree.add("MSc");
        typeOfDegree.add("MA");
        typeOfDegree.add("MEd");
        typeOfDegree.add("LLM");
        typeOfDegree.add("MBA");
        typeOfDegree.add("MRes");
        typeOfDegree.add("PHD");

        ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item, typeOfDegree);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_item);
        typeOf.setAdapter(adapter);

        ArrayList<String> typeOfPass = new ArrayList<String>();
        typeOfPass.add("Type of Passport");
        typeOfPass.add("UK");
        typeOfPass.add("EU");
        typeOfPass.add("INDIAN");


        ArrayAdapter adapter1 = new ArrayAdapter(this, android.R.layout.simple_spinner_item, typeOfPass);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_item);
        passW.setAdapter(adapter1);



    }
}
