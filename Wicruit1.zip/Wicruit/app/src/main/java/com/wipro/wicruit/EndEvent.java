package com.wipro.wicruit;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import java.util.ArrayList;

public class EndEvent extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_end_event);

        DatabaseClass databaseHelper = new DatabaseClass(this);
        ArrayList<String> listPro =databaseHelper.getEndAll();
        Spinner sp = (Spinner)findViewById(R.id.spinner1);
        ArrayAdapter<String> adapter= new ArrayAdapter<String>(this,R.layout.spinner_layout,R.id.txt,listPro);
        sp.setAdapter(adapter);
    }
}
