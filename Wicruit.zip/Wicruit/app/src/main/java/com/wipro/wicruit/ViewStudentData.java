package com.wipro.wicruit;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import de.codecrafters.tableview.TableDataAdapter;
import de.codecrafters.tableview.TableView;
import de.codecrafters.tableview.listeners.OnScrollListener;
import de.codecrafters.tableview.listeners.TableDataClickListener;
import de.codecrafters.tableview.toolkit.SimpleTableDataAdapter;
import de.codecrafters.tableview.toolkit.SimpleTableHeaderAdapter;

public class ViewStudentData extends AppCompatActivity {

    DatabaseClass databaseHelper = new DatabaseClass(this);

    private static String[][] Student = {};
    private static final String[] Header = { "First name", "Second Name", "Course", "Passport" };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_student_data);

        TableView<String[]> tableView = (TableView<String[]>) findViewById(R.id.tableView);

        populateStudent();

        tableView.setHeaderAdapter(new SimpleTableHeaderAdapter(this, Header));
        tableView.setDataAdapter(new SimpleTableDataAdapter(this, Student));

        tableView.addDataClickListener(new TableDataClickListener() {
            @Override
            public void onDataClicked(int rowIndex, Object clickedData) {
                Intent successLogin = new Intent(ViewStudentData.this, SingleStudentData.class);
                startActivity(successLogin);

                Toast.makeText(ViewStudentData.this, ((String[])clickedData)[1], Toast.LENGTH_SHORT).show();
            }
        });
    }
    private class MyOnScrollListener implements OnScrollListener {
        @Override
        public void onScroll(final ListView tableDataView, final int firstVisibleItem, final int visibleItemCount, final int totalItemCount) {
            // listen for scroll changes
        }

        @Override
        public void onScrollStateChanged(final ListView tableDateView, final ScrollState scrollState) {
            // listen for scroll state changes
        }
    }

    private void populateStudent(){
        Student student;
        ArrayList<Student> st = new ArrayList<>();
//        DatabaseClass databaseHelper = new DatabaseClass(this);
//        ArrayList<String> student =databaseHelper.getStudent();
//        TableView tb = (TableView) findViewById(R.id.tableView);
//        TableView<String[]> tableViews = (TableView<String[]>) findViewById(R.id.tableView);
//        tableView.setDataAdapter(new SimpleTableDataAdapter(this, student));

        databaseHelper.getStudent();

        student = new Student();
        student.setFirstName("jacob");
        student.setSurname("john");
        student.setCourseTitle("maths");
        student.setPassportType("british");
        st.add(student);

        student = new Student();
        student.setFirstName("jacob");
        student.setSurname("john");
        student.setCourseTitle("maths");
        student.setPassportType("british");
        st.add(student);


        Student = new String [st.size()][4];

        ArrayList<String> stuArraylist =databaseHelper.getStudent();
        for (int i = 0; i < st.size(); i++){
            Student student1 = st.get(i);
            Student[i][0] = student1.getFirstName();
            Student[i][1] = student1.getSurname();
            Student[i][2] = student1.getCourseTitle();
            Student[i][3] = student1.getPassportType();

        }
    }


}


