package com.wipro.wicruit;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import java.util.ArrayList;

public class SingleStudentData extends AppCompatActivity {

    private String name;
    DatabaseClass databaseHelper;
    ArrayList<String> st1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_single_student_data);


        //DisplayAllStudentInfo();


    }



    public SingleStudentData() {
    }





    public void DisplayAllStudentInfo() {

        Log.d("PKA1", "calling database to get name");
        st1 = databaseHelper.getStudentName();




    }
}

