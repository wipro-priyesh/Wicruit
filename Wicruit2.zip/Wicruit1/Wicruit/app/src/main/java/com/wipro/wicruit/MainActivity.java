package com.wipro.wicruit;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {


    private Button loginButton;     //For the login Button
    String emailId;
    String password1;

    DatabaseClass db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = new DatabaseClass(this);

        loginButton = (Button) this.findViewById(R.id.loginBtn);
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                 db.insertData("1", "0");
                // db.insertData("test@wipro.com", "123");
                // db.insertData("demo@wipro.com", "123");


                String e = GetEmail();
                GetPassword();
                if (checkCredentials() == true) {
                  Intent successLogin = new Intent(MainActivity.this, EventsHome.class);startActivity(successLogin);
                }

            }
        });

        //Forget/Reset Password OnClickListener
        TextView reset;
        reset = (TextView) findViewById(R.id.forogtPwordbtn);
        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent resetPassowrd = new Intent(MainActivity.this, ResetPassword.class);
                startActivity(resetPassowrd);
            }
        });
    }

    //Method to get the email from the EditText box
    private String GetEmail() {
        String empty = "";
        EditText emailET = (EditText) findViewById(R.id.userNameBtn);
        emailId = emailET.getText().toString();
   //     String unamecheck = db.ValidateCredentials(emailId);
        if (TextUtils.isEmpty(emailId)) {
            Toast.makeText(this, "Please Enter an Email Id", Toast.LENGTH_SHORT).show();
            return "please enter email id";
        } /*else if (!unamecheck.equals(emailId)) {
            Toast.makeText(this, "Please enter a valid email id", Toast.LENGTH_SHORT).show();
            return "Please enter a valid email id";
        }*/
        return emailId;
    }

    //Method to get the Password from the EditText box
    private String GetPassword() {
        EditText password = (EditText) findViewById(R.id.passWordBtn);
        password1 = password.getText().toString();
    //    String passcheck = db.search(password1);
        if (TextUtils.isEmpty(password1)) {
            Toast.makeText(this, "Please Enter a Password", Toast.LENGTH_SHORT).show();
        }
        return password1;
    }

    //Check if the email id and password entered by the user is correct.
    public boolean checkCredentials() {
   //     String pass = db.search(password1);
   //     String uname = db.ValidateCredentials(emailId);
        boolean check = db.ValidateCredentials(emailId, password1);
        if (check) {
            return true;
        } else if (!TextUtils.isEmpty(password1) && !TextUtils.isEmpty(emailId)) {
            Toast.makeText(MainActivity.this, "Incorrect Email ID / Password", Toast.LENGTH_SHORT).show();

            return false;
        }
        return false;
    }
}