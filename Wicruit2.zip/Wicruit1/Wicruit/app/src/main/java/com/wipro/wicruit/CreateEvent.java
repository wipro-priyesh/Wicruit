package com.wipro.wicruit;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class CreateEvent extends AppCompatActivity {

    DatabaseClass myDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_event);

        myDB = new DatabaseClass(this);

        //Save and Continue Toast
        Button Save = (Button) this.findViewById(R.id.scEvent_Btn);
        Save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText etEventTitle = (EditText) findViewById(R.id.eventTitle_editTxt);
                String EventTitle = etEventTitle.getText().toString();

                EditText etEventType = (EditText) findViewById(R.id.eventType_editTxt);
                String EventType = etEventType.getText().toString();

                EditText etLocation = (EditText) findViewById(R.id.location_editTxt);
                String Location = etLocation.getText().toString();

                EditText etEventDate = (EditText) findViewById(R.id.eventDate_editTxt);
                String EventDate = etEventDate.getText().toString();

                myDB.insertEventData(EventTitle, EventType, Location, EventDate, "Draft");
                Toast.makeText(CreateEvent.this, EventTitle + " " + EventType + " " + Location + " " + EventDate, Toast.LENGTH_LONG).show();

                Intent successLogin = new Intent(CreateEvent.this, EventsHome.class);
                startActivity(successLogin);


            }
        });

        Button Submit = (Button) this.findViewById(R.id.submitEvent_Btn);
        Submit.setOnClickListener(new View.OnClickListener() {
                                      @Override
                                      public void onClick(View v) {

                  EditText etEventTitle = (EditText) findViewById(R.id.eventTitle_editTxt);
                  String EventTitle = etEventTitle.getText().toString();

                  EditText etEventType = (EditText) findViewById(R.id.eventType_editTxt);
                  String EventType = etEventType.getText().toString();

                  EditText etLocation = (EditText) findViewById(R.id.location_editTxt);
                  String Location = etLocation.getText().toString();

                  EditText etEventDate = (EditText) findViewById(R.id.eventDate_editTxt);
                  String EventDate = etEventDate.getText().toString();
                  if (EventTitle.isEmpty() || EventType.isEmpty() || Location.isEmpty() || EventDate.isEmpty()) {
                      Toast.makeText(CreateEvent.this, "You have not filled out all fields, please check again", Toast.LENGTH_LONG).show();

                  } else {
                        myDB.insertEventData(EventTitle, EventType, Location, EventDate, "Complete");
                        Toast.makeText(CreateEvent.this, EventTitle + " " + EventType + " " + Location + " " + EventDate, Toast.LENGTH_LONG).show();
                        Intent successLogin = new Intent(CreateEvent.this, EventsHome.class);
                        startActivity(successLogin);

                  }


                                      }
                              }

        );
    }
}
